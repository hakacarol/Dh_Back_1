package mesa_de_trabalho.model;

public enum Tamanho {
    P,
    M,
    G
}
