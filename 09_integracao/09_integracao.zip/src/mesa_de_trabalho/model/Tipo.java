package mesa_de_trabalho.model;

public enum Tipo {
    CALÇA,
    CAMISA
}
