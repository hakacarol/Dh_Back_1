import dao.ServidorPaciente;

public class Main {
    public static void main(String[] args) {
        ServidorPaciente servidorPaciente = new ServidorPaciente();
        servidorPaciente.create();
    }
}
