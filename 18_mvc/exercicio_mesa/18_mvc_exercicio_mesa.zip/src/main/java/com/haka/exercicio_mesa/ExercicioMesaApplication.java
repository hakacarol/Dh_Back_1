package com.haka.exercicio_mesa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioMesaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioMesaApplication.class, args);
	}

}
