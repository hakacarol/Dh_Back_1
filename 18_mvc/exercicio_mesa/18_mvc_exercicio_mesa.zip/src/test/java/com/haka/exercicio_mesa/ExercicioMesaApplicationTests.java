package com.haka.exercicio_mesa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioMesaApplicationTests {

	@Test
	void contextLoads() {
	}

}
