package com.haka.exercicio_aula19;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioAula19Application {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioAula19Application.class, args);
	}

}
