package com.haka.exercicio_aula19;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioAula19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
