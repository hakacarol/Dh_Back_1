package com.haka._integracao.dao;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DentistaDao {

    private Integer id;
    private String nome;
    private String sobrenome;
    private String matricula;
}
