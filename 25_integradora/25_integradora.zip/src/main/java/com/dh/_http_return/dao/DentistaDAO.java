package com.dh._http_return.dao;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DentistaDAO {
    private Integer id;
    private String nome;
    private String email;
    private String credencial;
}
